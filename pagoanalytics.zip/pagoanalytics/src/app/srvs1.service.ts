import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class Srvs1Service {

  constructor(private http: HttpClient) { }

  getMethod() {
    return this.http.get('https://reqres.in/api/users?page=1');
  }
}
