import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { Srvs1Service } from '../srvs1.service';

@Component({
  selector: 'app-navbar2',
  templateUrl: './navbar2.component.html',
  styleUrls: ['./navbar2.component.css']
})
export class Navbar2Component implements OnInit {
  subscription!: Subscription;
  data: any;

  constructor(private srvs: Srvs1Service) { }

  ngOnInit(): void {
   this.subscription =  this.srvs.getMethod().subscribe(data => {
      this.data = data;
    })
  }
  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

}
